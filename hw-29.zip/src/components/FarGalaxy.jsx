import { useState, useEffect } from "react";
import { Oval } from 'react-loader-spinner';
import { url } from "../utils/constants.js";

const FarGalaxy = () => {
    const [text, setText] = useState("Loading...");
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        const fetchOpeningCrawl = async () => {
                const randomId = Math.floor(Math.random() * 6) + 1;

                const response = await fetch(url + randomId);
                if (!response.ok) {
                    setText("Cannot load data");
                    setIsLoading(false);
                    return;
                }

                const data = await response.json();
                setText(data.opening_crawl);
                setIsLoading(false);
        };

        fetchOpeningCrawl();
    }, []);

    return (
        <div>
            {isLoading ? (
                <Oval
                    height={80}
                    width={80}
                    color="#00BFFF"
                    ariaLabel="loading"
                    wrapperStyle={{ display: 'flex', justifyContent: 'center', alignItems: 'center' }}
                />
            ) : (
                <p className="farGalaxy">{text}</p>
            )}
        </div>
    );
};

export default FarGalaxy;